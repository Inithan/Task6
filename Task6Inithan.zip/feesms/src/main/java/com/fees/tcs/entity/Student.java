package com.fees.tcs.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Student")
public class Student implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int student_ID;
    private String first_Name;
    private String last_Name;
    private Date dob;
    private String gender;
    private String address;
    private String email;
    private String major_Program;
    private double gpa;
    private String status;
	@OneToMany(mappedBy = "student", cascade = CascadeType.ALL)
    private List<Fees> feesList;
	public int getStudent_ID() {
		return student_ID;
	}
	public void setStudent_ID(int student_ID) {
		this.student_ID = student_ID;
	}
	public String getFirst_Name() {
		return first_Name;
	}
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	public String getLast_Name() {
		return last_Name;
	}
	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMajor_Program() {
		return major_Program;
	}
	public void setMajor_Program(String major_Program) {
		this.major_Program = major_Program;
	}
	public double getGpa() {
		return gpa;
	}
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<Fees> getFeesList() {
		return feesList;
	}
	public void setFeesList(List<Fees> feesList) {
		this.feesList = feesList;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((feesList == null) ? 0 : feesList.hashCode());
		result = prime * result + ((first_Name == null) ? 0 : first_Name.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		long temp;
		temp = Double.doubleToLongBits(gpa);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((last_Name == null) ? 0 : last_Name.hashCode());
		result = prime * result + ((major_Program == null) ? 0 : major_Program.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + student_ID;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (feesList == null) {
			if (other.feesList != null)
				return false;
		} else if (!feesList.equals(other.feesList))
			return false;
		if (first_Name == null) {
			if (other.first_Name != null)
				return false;
		} else if (!first_Name.equals(other.first_Name))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (Double.doubleToLongBits(gpa) != Double.doubleToLongBits(other.gpa))
			return false;
		if (last_Name == null) {
			if (other.last_Name != null)
				return false;
		} else if (!last_Name.equals(other.last_Name))
			return false;
		if (major_Program == null) {
			if (other.major_Program != null)
				return false;
		} else if (!major_Program.equals(other.major_Program))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (student_ID != other.student_ID)
			return false;
		return true;
	}
	public Student(int student_ID, String first_Name, String last_Name, Date dob, String gender, String address,
			String email, String major_Program, double gpa, String status, List<Fees> feesList) {
		super();
		this.student_ID = student_ID;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.dob = dob;
		this.gender = gender;
		this.address = address;
		this.email = email;
		this.major_Program = major_Program;
		this.gpa = gpa;
		this.status = status;
		this.feesList = feesList;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [student_ID=" + student_ID + ", first_Name=" + first_Name + ", last_Name=" + last_Name
				+ ", dob=" + dob + ", gender=" + gender + ", address=" + address + ", email=" + email
				+ ", major_Program=" + major_Program + ", gpa=" + gpa + ", status=" + status + ", feesList=" + feesList
				+ "]";
	}
	
	
	
	}
