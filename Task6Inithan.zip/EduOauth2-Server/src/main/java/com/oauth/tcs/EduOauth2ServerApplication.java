package com.oauth.tcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduOauth2ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduOauth2ServerApplication.class, args);
	}

}
